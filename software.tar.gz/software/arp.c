#include <libnet.h>
#include <stdio.h>

#define ARP_REQUEST    1
#define ARP_REPLY      2
#define ARP_ETHER_TYPE 0x806

uint8_t* str_to_hw(char*);
uint32_t str_to_ip(libnet_t*, char*);

int main(int argc, char* argv[])
{
   if (argc < 2) {
       printf("Usage: %s [device] [source_ip] [source_mac] [target_ip] [target_mac] [op]\n", argv[0]);
       return 0;
   }

   const char* device = argv[1];

   char errbuf[LIBNET_ERRBUF_SIZE];
   libnet_t* context = libnet_init(LIBNET_LINK_ADV, device, errbuf);

   if (context == NULL) {
       fprintf(stderr, "Fatal error while initializing libnet: %s\n", errbuf);
       return 1;
   }

   uint8_t* source_mac = str_to_hw(argv[3]);
   uint8_t* target_mac = str_to_hw(argv[5]);
   uint32_t source_ip  = str_to_ip(context, argv[2]);
   uint32_t target_ip  = str_to_ip(context, argv[4]);

   printf("Building ARP header...\n");
   libnet_autobuild_arp(
           ARP_REPLY,
           source_mac,
           (uint8_t*) &source_ip,
           target_mac,
           (uint8_t*) &target_ip,
           context);

   printf("Building ethernet header...\n");
   libnet_autobuild_ethernet(
           target_mac,
           ARP_ETHER_TYPE,
           context);

   printf("Dispatching packet...\n");
   int bytes_written = libnet_write(context);

   if (bytes_written > 1) {
       printf("Wrote %d bytes to the network\n", bytes_written);
   } else {
       printf("Error while dispatching packet: %s", libnet_geterror(context));
   }

   libnet_destroy(context);

   return 0;
}

uint8_t* str_to_hw(char* str)
{
   int addr_size;
   return libnet_hex_aton(str, &addr_size);
}

uint32_t str_to_ip(libnet_t* con, char* str)
{
   return libnet_name2addr4(con, str, LIBNET_RESOLVE);
}
